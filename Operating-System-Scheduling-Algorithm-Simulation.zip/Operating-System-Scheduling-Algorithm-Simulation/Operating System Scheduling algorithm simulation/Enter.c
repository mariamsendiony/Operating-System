#include <stdio.h>
#include <stdlib.h>

int main(){
    char* sugar = "Sugar";
    char h = '5';
    int hConverted = h -'0';
    printf("There are many %d",hConverted);

}